package quiz_management_system_java;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Student_Login extends JFrame implements ActionListener {
    private JPanel panel;
	private JTextField textField;
	private JPasswordField passwordField;
        private JButton b1,b2;


	public Student_Login() {
            
	setBackground(new Color(169, 169, 169));	
        setBounds(600, 300, 600, 400);
		
        panel = new JPanel();
	panel.setBackground(new Color(176, 224, 230));
	setContentPane(panel);
	panel.setLayout(null);

	JLabel l1 = new JLabel("Username : ");
	l1.setBounds(124, 89, 95, 24);
	panel.add(l1);

	JLabel l2 = new JLabel("Password : ");
	l2.setBounds(124, 124, 95, 24);
	panel.add(l2);

	textField = new JTextField();
	textField.setBounds(210, 93, 157, 20);
	panel.add(textField);
	
	passwordField = new JPasswordField();
	passwordField.setBounds(210, 128, 157, 20);
	panel.add(passwordField);
        
	b1 = new JButton("Login");
	b1.addActionListener(this);
                
	b1.setForeground(new Color(46, 139, 87));
	b1.setBackground(new Color(250, 250, 210));
	b1.setBounds(170, 181, 113, 39);
	panel.add(b1);
        
        b2 = new JButton("Exit");
	b2.addActionListener(this);
                
	b2.setForeground(new Color(46, 139, 87));
	b2.setBackground(new Color(250, 250, 210));
	b2.setBounds(300, 181, 113, 39);
	panel.add(b2);
		
        
        }
	public void actionPerformed(ActionEvent ae)
        {
                 if(ae.getSource()==b1){
                     String user=textField.getText();
                  String pass=passwordField.getText();
                  if(user.equals("admin")&&pass.equals("admin@123"))
                  {
                     new Quizz_frame().setVisible(true);
                     this.setVisible(false);
                  }
                 }
                 else
                 {
                     System.exit(0);
                 }
        }

	
}
