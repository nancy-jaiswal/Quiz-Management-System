package quiz_management_system_java;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

 
public class Quizz_frame extends JFrame implements ActionListener {
       private JPanel panel;
    JLabel label;
    JRadioButton radiobuttons[]=new JRadioButton[5];
    JButton btnNext,btnResult;
    ButtonGroup bg;
    int count=0,current=0,x=1,y=1,now=0;
    int m[]=new int[10];
    
    public Quizz_frame()
    {
        setBackground(new Color(169, 169, 169));	
        setBounds(600, 300, 600, 400);
        
         panel = new JPanel();
	panel.setBackground(new Color(176, 224, 230));
	setContentPane(panel);
	panel.setLayout(null);
        
        
        label=new JLabel();
        add(label);
        bg=new ButtonGroup();
        for(int i=0;i<5;i++)
        {
            radiobuttons[i]=new JRadioButton();
            add(radiobuttons[i]);
            bg.add(radiobuttons[i]);
        }
        btnNext=new JButton("Next");
        btnResult=new JButton("Result");
        btnResult.setVisible(false);
        btnResult.addActionListener(this);
        btnNext.addActionListener(this);
        add(btnNext);
        add(btnResult);
        setData();
        label.setBounds(30, 40, 450, 20);
        radiobuttons[0].setBounds(50,80,450,20);
        radiobuttons[1].setBounds(50,110,200,20);
        radiobuttons[2].setBounds(50,140,200,20);
        radiobuttons[3].setBounds(50,170,200,20);
        btnNext.setBounds(100,240,100,30);
        btnResult.setBounds(270,240,100,30);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setVisible(true);
        setSize(600,350);
        setBounds(600, 300, 600, 400);
        
        
    }
    void setData()
    {
        radiobuttons[4].setSelected(true);
        if(current==0)
        {
            label.setText("Q1. :Which is the official language for Android Development?");
            radiobuttons[0].setText("Java");
            radiobuttons[1].setText("Kotlin");
            radiobuttons[2].setText("C++");
            radiobuttons[3].setText("JavaScript");
        }
        if (current == 1) {
			label.setText("Que2:  Which feature of java 7 allows to not explicitly close IO resource?");
			radiobuttons[0].setText("try catch finally");
			radiobuttons[1].setText("IOException");
			radiobuttons[2].setText("AutoCloseable");
			radiobuttons[3].setText("Streams");
		}
		if (current == 2) {
			label.setText("Que3: SessionFactory is a thread-safe object.");
			radiobuttons[0].setText("true");
			radiobuttons[1].setText("false");
			radiobuttons[2].setText("don't know");
			radiobuttons[3].setText("false");
		}
		if (current == 3) {
			label.setText("Que4: Which is the new method introduced in java 8 to iterate over a collection?");
			radiobuttons[0].setText("for (String i : StringList)");
			radiobuttons[1].setText("foreach (String i : StringList)");
			radiobuttons[2].setText("StringList.forEach()");
			radiobuttons[3].setText("List.for()");
		}
		if (current == 4) {
			label.setText("Que5:  What is the substitute of Rhino javascript engine in Java 8?");
			radiobuttons[0].setText(" Nashorn");
			radiobuttons[1].setText("V8");
			radiobuttons[2].setText("Inscript");
			radiobuttons[3].setText("Narcissus");
		}
		if (current == 5) {
			label.setText("Que6: How to read entire file in one line using java 8?");
			radiobuttons[0].setText("Files.readAllLines()");
			radiobuttons[1].setText("Files.read()");
			radiobuttons[2].setText("Files.readFile()");
			radiobuttons[3].setText("Files.lines()");
		}
		if (current == 6) {
			label.setText("Que7:  Which feature of java 7 allows to not explicitly close IO resource?");
			radiobuttons[0].setText("try catch finally");
			radiobuttons[1].setText("IOException");
			radiobuttons[2].setText("AutoCloseable");
			radiobuttons[3].setText("Streams");
		}
		if (current == 7) {
			label.setText("Que8:  Which of the following is not a core interface of Hibernate?");
			radiobuttons[0].setText("Configuration");
			radiobuttons[1].setText("Criteria");
			radiobuttons[2].setText("SessionManagement");
			radiobuttons[3].setText("Session");
		}
		if (current == 8) {
			label.setText("Que9: SessionFactory is a thread-safe object.");
			radiobuttons[0].setText("true");
			radiobuttons[1].setText("false");
			radiobuttons[2].setText("don't know");
			radiobuttons[3].setText("false");
		}
		if (current == 9) {
			label.setText("Que10: Which of the following is not a state of object in Hibernate?");
			radiobuttons[0].setText("Attached()");
			radiobuttons[1].setText("Detached()");
			radiobuttons[2].setText("Persistent()");
			radiobuttons[3].setText("Transient()");
		}

        label.setBounds(30, 40,450,20);
        for(int i=0,j=0;i<=90;i+=30,j++)
        {
            radiobuttons[j].setBounds(50,80+i,200,20);
        }
    }
    boolean checkans()
    {
        if(current==0)
        {
            return(radiobuttons[1].isSelected());
        }
        if(current==1)
        {
            return(radiobuttons[1].isSelected());
        }
        if(current==2)
        {
            return(radiobuttons[0].isSelected());
        }
        if(current==3)
        {
            return(radiobuttons[2].isSelected());
        }
        if(current==4)
        {
            return(radiobuttons[0].isSelected());
        }
        if(current==5)
        {
            return(radiobuttons[0].isSelected());
        }
        if(current==6)
        {
            return(radiobuttons[1].isSelected());
        }
        if(current==7)
        {
            return(radiobuttons[2].isSelected());
        }
        if(current==8)
        {
            return(radiobuttons[0].isSelected());
        }
        if(current==9)
        {
            return(radiobuttons[0].isSelected());
        }
        return false;
     }
 public  static void main(String [] args)
 {
     new Quizz_frame();
 }
 public void actionPerformed(ActionEvent e)
 {
       if(e.getSource()==btnNext)
       {
           if(checkans())
               count=count+1;
           current++;
           setData();
           if(current==9){
               btnNext.setEnabled(false);
               btnResult.setVisible(true);
               btnResult.setText("Result");
       }
       }
       if(e.getActionCommand().equals("Result"))
       {
           if(checkans())
               count=count+1;
           current++;
           JOptionPane.showMessageDialog(this, "Correct Answers are"+count);
           System.exit(0);
       }
 }
}
